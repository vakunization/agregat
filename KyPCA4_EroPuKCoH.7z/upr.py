import galois

# Определяем поле GF(2^4) с примитивным полиномом x^4 + x + 1
GF = galois.GF(2**4, irreducible_poly="x^4 + x + 1")
α = GF.primitive_element

# Порождающий многочлен g(x) = (x-α^6)(x-α^7)(x-α^8)(x-α^9)(x-α^10)(x-α^11)
factors = []
for i in range(6, 12):  # 6, 7, 8, 9, 10, 11
    factors.append(galois.Poly([1, -α**i], field=GF))  # полином (x - α^i)

# Умножаем все множители
g_poly = galois.Poly([1], field=GF)  # начальное значение
for factor in factors:
    g_poly = g_poly * factor

print("Порождающий многочлен g(x):")
print(f"g(x) = {g_poly}")

# Выводим коэффициенты в удобном виде
print("\nКоэффициенты g(x) в виде степеней α:")
for i, coeff in enumerate(g_poly.coeffs):
    if coeff != 0:
        exp = coeff.log()
        power = len(g_poly.coeffs) - 1 - i
        print(f"Коэффициент при x^{power}: α^{exp}")
    else:
        power = len(g_poly.coeffs) - 1 - i
        print(f"Коэффициент при x^{power}: 0")
