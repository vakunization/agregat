import numpy as np
import galois

# Инициализация поля GF(2^4) с примитивным полиномом x^4 + x + 1
GF = galois.GF(2**4, irreducible_poly="x^4 + x + 1")
print("Поле GF(2^4) с примитивным полиномом x^4 + x + 1:")
print(f"Примитивный элемент α = {GF.primitive_element}\n")
print(f"Все элементы поля:")
for i in range(15):
    element = GF.primitive_element ** i
    print(f"α^{i} = {element}")
print()

# Определение синдромов S1-S6 (S1 = S_6, S2 = S_7, ..., S6 = S_11)
print("Вычисление синдромов S_j для j = 1..6 (соответствуют S_6..S_11):")
alpha = GF.primitive_element

# Синдромы согласно заданию
S1 = alpha**4  # α^4
S2 = alpha**2  # α^2
S3 = alpha**4  # α^4
S4 = alpha**1  # α^1
S5 = alpha**14 # α^14
S6 = alpha**1  # α^1

print(f"S1 = α^4 = {S1}")
print(f"S2 = α^2 = {S2}")
print(f"S3 = α^4 = {S3}")
print(f"S4 = α^1 = {S4}")
print(f"S5 = α^14 = {S5}")
print(f"S6 = α^1 = {S6}")
print()

# Вычисление определителей
print("=" * 60)
print("Вычисление определителей Δ2 и Δ3:")
print("=" * 60)

print("\n1. Вычисляем Δ2 = S1*S3 + S2^2")
print(f"   S1 * S3 = α^4 * α^4 = α^{4+4} = α^8")
S1_S3 = S1 * S3
print(f"           = {S1} * {S3} = {S1_S3} = α^{int(np.log(S1_S3))}")

print(f"\n   S2^2 = (α^2)^2 = α^4")
S2_sq = S2**2
print(f"        = {S2}^2 = {S2_sq} = α^{int(np.log(S2_sq))}")

print(f"\n   Δ2 = S1*S3 + S2^2 = α^8 + α^4")
Delta2 = S1_S3 + S2_sq
print(f"       = {S1_S3} + {S2_sq} = {Delta2}")
if Delta2 != 0:
    print(f"       = α^{int(np.log(Delta2))}")
else:
    print("       = 0")
print()

print("\n2. Вычисляем Δ3 (определитель матрицы 3x3):")
print("   | S1 S2 S3 |")
print("   | S2 S3 S4 |")
print("   | S3 S4 S5 |")
print()
print("   Δ3 = S1*(S3*S5 + S4^2) + S2*(S2*S5 + S3*S4) + S3*(S2*S4 + S3^2)")

# Вычисляем компоненты
print(f"\n   Вычисляем компоненты:")
print(f"   S3*S5 = α^4 * α^14 = α^{4+14} = α^{18 % 15} = α^3")
term1 = S3 * S5
print(f"         = {S3} * {S5} = {term1} = α^{int(np.log(term1))}")

print(f"   S4^2 = (α^1)^2 = α^2")
term2 = S4**2
print(f"        = {S4}^2 = {term2} = α^{int(np.log(term2))}")

print(f"\n   S3*S5 + S4^2 = α^3 + α^2")
part1 = term1 + term2
print(f"                = {term1} + {term2} = {part1}")

print(f"\n   S2*S5 = α^2 * α^14 = α^{2+14} = α^{16 % 15} = α^1")
term3 = S2 * S5
print(f"         = {S2} * {S5} = {term3} = α^{int(np.log(term3))}")

print(f"   S3*S4 = α^4 * α^1 = α^5")
term4 = S3 * S4
print(f"         = {S3} * {S4} = {term4} = α^{int(np.log(term4))}")

print(f"\n   S2*S5 + S3*S4 = α^1 + α^5")
part2 = term3 + term4
print(f"                  = {term3} + {term4} = {part2}")

print(f"\n   S2*S4 = α^2 * α^1 = α^3")
term5 = S2 * S4
print(f"         = {S2} * {S4} = {term5} = α^{int(np.log(term5))}")

print(f"   S3^2 = (α^4)^2 = α^8")
term6 = S3**2
print(f"        = {S3}^2 = {term6} = α^{int(np.log(term6))}")

print(f"\n   S2*S4 + S3^2 = α^3 + α^8")
part3 = term5 + term6
print(f"                = {term5} + {term6} = {part3}")
print()

# Вычисляем Δ3
print(f"   Вычисляем Δ3:")
print(f"   S1*(S3*S5 + S4^2) = α^4 * ({part1})")

comp1 = S1 * part1
print(f"                     = {S1} * {part1} = {comp1}")

print(f"\n   S2*(S2*S5 + S3*S4) = α^2 * ({part2})")
comp2 = S2 * part2
print(f"                      = {S2} * {part2} = {comp2}")

print(f"\n   S3*(S2*S4 + S3^2) = α^4 * ({part3})")
comp3 = S3 * part3
print(f"                     = {S3} * {part3} = {comp3}")

print(f"\n   Δ3 = {comp1} + {comp2} + {comp3}")
Delta3 = comp1 + comp2 + comp3
print(f"      = {comp1 + comp2} + {comp3}")
print(f"      = {comp1 + comp2 + comp3}")

if Delta3 == 0:
    print(f"   Δ3 = 0")
else:
    print(f"   Δ3 = {Delta3} = α^{int(np.log(Delta3))}")
print()

# Определение числа ошибок
print("=" * 60)
print("Определение числа ошибок:")
print("=" * 60)
print(f"Δ2 = {Delta2} {'≠ 0' if Delta2 != 0 else '= 0'}")
print(f"Δ3 = {Delta3} {'≠ 0' if Delta3 != 0 else '= 0'}")
print()
print("Так как Δ2 ≠ 0 и Δ3 = 0, предполагаем 2 ошибки")
print("Количество ошибок ν = 2")
print()

# Решение системы уравнений для полинома локаторов ошибок
print("=" * 60)
print("Решение системы уравнений для полинома локаторов ошибок Λ(x):")
print("=" * 60)
print("Для ν = 2, система уравнений имеет вид:")
print("  [ S1  S2 ] [ Λ₂ ]   [ S₃ ]")
print("  [ S₂  S₃ ] [ Λ₁ ] = [ S₄ ]")
print()
print(f"  [ {S1}  {S2} ] [ Λ₂ ]   [ {S3} ]")
print(f"  [ {S2}  {S3} ] [ Λ₁ ] = [ {S4} ]")
print()

# Матрица системы
M = GF([[S1, S2], [S2, S3]])
b = GF([S3, S4])

print(f"Матрица M:")
print(f"  [{S1}, {S2}]")
print(f"  [{S2}, {S3}]")
print()
print(f"Вектор b = [{S3}, {S4}]")

# Проверяем определитель
print(f"\nОпределитель матрицы M = det(M) = Δ2 = {Delta2}")
print(f"Так как определитель ≠ 0, система имеет решение")
print()

# Решаем систему
print("Решаем систему методом Крамера:")
print("Λ₂ = det([S₃ S₂; S₄ S₃]) / Δ2")
print(f"   = ({S3}*{S3} + {S2}*{S4}) / {Delta2}")

det_num1 = S3 * S3
det_num2 = S2 * S4
print(f"   = ({det_num1} + {det_num2}) / {Delta2}")
det_num = det_num1 + det_num2
print(f"   = {det_num} / {Delta2}")

Lambda2 = det_num / Delta2
print(f"   = {Lambda2} = α^{int(np.log(Lambda2))}")
print()

print("Λ₁ = det([S₁ S₃; S₂ S₄]) / Δ2")
print(f"   = ({S1}*{S4} + {S3}*{S2}) / {Delta2}")

det_num3 = S1 * S4
det_num4 = S3 * S2
print(f"   = ({det_num3} + {det_num4}) / {Delta2}")
det_num_b = det_num3 + det_num4
print(f"   = {det_num_b} / {Delta2}")

Lambda1 = det_num_b / Delta2
print(f"   = {Lambda1} = α^{int(np.log(Lambda1))}")
print()

# Формируем полином локаторов ошибок
print("=" * 60)
print("Полином локаторов ошибок Λ(x):")
print("=" * 60)
print("Λ(x) = 1 + Λ₁x + Λ₂x²")
print(f"     = 1 + ({Lambda1})x + ({Lambda2})x²")

# Создаем полином
poly_coeffs = GF([1, Lambda1, Lambda2])  # Порядок: младшая степень сначала
poly = galois.Poly(poly_coeffs, field=GF)

print(f"\nПолином в виде списка коэффициентов (от младшей степени):")
print(f"  {poly.coeffs}")
print(f"\nПолином в обычной форме:")
print(f"  Λ(x) = {poly}")
print()

# Проверяем правильность решения
print("=" * 60)
print("Проверка решения:")
print("=" * 60)

print("1. Проверка первого уравнения:")
print(f"   S₁Λ₂ + S₂Λ₁ = S₃ ?")
left1 = S1 * Lambda2 + S2 * Lambda1
print(f"   {S1}·{Lambda2} + {S2}·{Lambda1} = {S1*Lambda2} + {S2*Lambda1}")
print(f"   = {S1*Lambda2} + {S2*Lambda1} = {S1*Lambda2 + S2*Lambda1}")
print(f"   S₃ = {S3}")
print(f"   Результат: {'✓ Верно' if left1 == S3 else '✗ Ошибка'}")
print()

print("2. Проверка второго уравнения:")
print(f"   S₂Λ₂ + S₃Λ₁ = S₄ ?")
left2 = S2 * Lambda2 + S3 * Lambda1
print(f"   {S2}·{Lambda2} + {S3}·{Lambda1} = {S2*Lambda2} + {S3*Lambda1}")
print(f"   = {S2*Lambda2} + {S3*Lambda1} = {S2*Lambda2 + S3*Lambda1}")
print(f"   S₄ = {S4}")
print(f"   Результат: {'✓ Верно' if left2 == S4 else '✗ Ошибка'}")
print()

# Находим корни полинома
print("=" * 60)
print("Нахождение корней полинома Λ(x):")
print("=" * 60)

roots = poly.roots()
print(f"Корни полинома Λ(x): {roots}")
print()

if len(roots) > 0:
    print("Преобразуем корни в локаторы ошибок Xᵢ = 1/корень:")
    for i, root in enumerate(roots):
        if root == 0:
            continue
        # В galois нужно использовать field(1) вместо просто 1
        one = GF(1)
        X = one / root
        root_power = int(np.log(root))
        X_power = int(np.log(X))
        print(f"  Корень {i+1}: r = {root} = α^{root_power}")
        print(f"    X = 1/r = 1/α^{root_power} = α^{-root_power} = α^{15-root_power} = α^{X_power}")
        print(f"    X = {X}")
        print(f"    Позиция ошибки: j = {X_power} (так как X = α^j)")
        print()
else:
    print("Полином не имеет корней в поле GF(2^4)")
print()

# Поиск локаторов перебором
print("=" * 60)
print("Поиск локаторов ошибок перебором всех элементов поля:")
print("=" * 60)

print("i  | α^i | Λ(α^i) | Корень?")
print("-" * 40)

found_roots = []
for i in range(15):  # Проверяем все элементы поля (0..14)
    element = alpha**i if i < 15 else GF(0)
    value = poly(element)
    
    # Для отображения
    element_str = f"α^{i}" if i < 15 else "0"
    value_str = f"{value}"
    if value != 0:
        value_str += f" = α^{int(np.log(value))}"
    
    is_root = value == 0
    if is_root:
        found_roots.append(element)
    
    root_str = "ДА" if is_root else "нет"
    print(f"{i:2} | {element_str:4} | {value_str:15} | {root_str}")

print()
print(f"Найдено корней: {len(found_roots)}")
if found_roots:
    print("Корни:", found_roots)
    for root in found_roots:
        if root != 0:
            one = GF(1)
            X = one / root
            power = int(np.log(root))
            X_power = int(np.log(X))
            print(f"  Для корня α^{power}: X = α^{X_power}")

# Проверяем соответствие заданным ошибкам
print("\n" + "=" * 60)
print("Проверка соответствия заданным ошибкам:")
print("=" * 60)

print("Исходные ошибки:")
print("  err1 = 8:a^8  (позиция 8, значение α^8)")
print("  err2 = 13:a^1 (позиция 13, значение α^1)")

print("\nНайденные локаторы ошибок X = α^j, где j - позиция ошибки:")
if found_roots:
    for i, root in enumerate(found_roots):
        if root != 0:
            one = GF(1)
            X = one / root
            j = int(np.log(X))
            print(f"  Локатор {i+1}: X = α^{j} (позиция j = {j})")
else:
    print("  Локаторы не найдены")

print("\nВывод:")
if len(found_roots) == 2:
    print("✓ Найдено 2 локатора ошибок, что соответствует 2 ошибкам")
    print("✓ Полином локаторов ошибок найден верно")
else:
    print("✗ Количество найденных локаторов не соответствует ожидаемым 2 ошибкам")
