import numpy as np
import galois

# Задаем поле GF(2^4) с примитивным полиномом p(x) = x^4 + x + 1
GF = galois.GF(2**4, irreducible_poly=[1, 1, 0, 0, 1])  # x^4 + x + 1
print(f"Поле GF(2^4) с примитивным полиномом x^4 + x + 1\n")

# Примитивный элемент α
alpha = GF.primitive_element
print(f"Примитивный элемент α = {alpha}\n")

# Полином локаторов ошибок σ(x) = 1 + α^4*x + α^8*x^2
# Коэффициенты от младшей степени к старшей: [σ0, σ1, σ2]
sigma_coeffs = [GF(1), GF(alpha**4), GF(alpha**8)]
sigma_poly = galois.Poly(sigma_coeffs, field=GF)
print(f"Полином локаторов ошибок σ(x) = {sigma_poly}")
print(f"Коэффициенты (от x^0 к x^2): {sigma_coeffs}\n")

# Метод Ченя-Форни: вычисляем σ(α^{-i}) для всех i=0..14
# Корни локаторов ошибок соответствуют позициям ошибок (обратные элементы)
print("Таблица вычисления σ(α^{-i}) методом Ченя-Форни:")
print("-" * 40)
print(f"{'i':>2} | {'α^{-i}':>10} | {'σ(α^{-i})':>10} | Ошибка в позиции i")
print("-" * 40)

error_positions = []

for i in range(15):  # Позиции 0..14 (x^14 соответствует позиция 14)
    # Вычисляем α^{-i} = α^(15-i) mod 15 (поскольку α^15 = 1)
    power = (15 - i) % 15
    if power == 0:
        power = 15
    x_inv = alpha ** power
    
    # Вычисляем значение полинома σ(x) в точке x = α^{-i}
    sigma_val = sigma_poly(x_inv)
    
    # Если σ(α^{-i}) = 0, то это корень -> ошибка в позиции i
    is_error = sigma_val == 0
    
    # Отображаем α^{-i} в виде α^k
    power_display = power if power < 15 else 0
    
    print(f"{i:2d} | α^{power_display:<8} | {str(sigma_val):>10} | {'Да' if is_error else 'Нет'}")
    
    if is_error:
        error_positions.append(i)

print("-" * 40)
print(f"\nНайдены позиции ошибок: {sorted(error_positions)}")

# Находим локаторы ошибок (обратные корням)
print(f"\nЛокаторы ошибок (обратные корням):")
for pos in error_positions:
    power = (15 - pos) % 15
    if power == 0:
        power = 15
    locator = alpha ** power
    print(f"  Позиция {pos}: α^{-pos} = α^{power} = {locator}")

# Проверяем наши вычисления через прямое нахождение корней
print(f"\nПроверка: корни полинома σ(x):")
roots = sigma_poly.roots()
for root in roots:
    # Находим позицию ошибки: α^{-i} = root => i = -log_α(root) mod 15
    # В galois можно найти степень через логарифм
    power = int(np.log(root))  # log_α(root)
    pos = (-power) % 15
    print(f"  Корень {root} = α^{power}: позиция ошибки = {pos}")
