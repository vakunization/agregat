import galois

GF = galois.GF(2**4, irreducible_poly="x^4 + x + 1")
α = GF.primitive_element

S1 = α**4
S2 = α**2
S3 = α**4
S4 = α**1
S5 = α**14

# Δ2 = S1*S3 + S2^2
Δ2 = S1 * S3 + S2**2
print(f"Δ2 = S1*S3 + S2^2 = {Δ2}")
if Δ2 != 0:
    print(f"Δ2 = α^{Δ2.log()}")
else:
    print("Δ2 = 0")

# Δ3 = S1*S3*S5 + S2*S4*S3 + S3*S4*S2 + S1*S4*S4 + S2*S2*S5 + S3*S3*S3
Δ3 = S1*S3*S5 + S2*S4*S3 + S3*S4*S2 + S1*S4*S4 + S2*S2*S5 + S3*S3*S3
print(f"\nΔ3 = {Δ3}")
if Δ3 != 0:
    print(f"Δ3 = α^{Δ3.log()}")
else:
    print("Δ3 = 0")
