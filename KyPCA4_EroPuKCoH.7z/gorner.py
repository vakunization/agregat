import galois

GF = galois.GF(2**4, irreducible_poly="x^4 + x + 1")
α = GF.primitive_element

# Коэффициенты e(x) от x^14 до x^0, все приведены к GF
coeffs_e = [
    α**7,   # x^14
    α**7,   # x^13
    α**4,   # x^12
    α**11,  # x^11
    α**13,   # x^10
    α**2,   # x^9
    α**5,  # x^8
    α**3,  # x^7
    α**5,   # x^6
    α**2,   # x^5
    α**2,   # x^4
    α**5,   # x^3
    α**2,   # x^2
    α**14,  # x^1
    α**10,   # x^0
]

roots = [α**j for j in [6, 7, 8, 9, 10, 11]]
syndromes = []

def xz(val):
    if val != 0:
        return val.log()
    else:
        return ".0"

for root in roots:
    # Схема Горнера
    print("coeff", "∑", root.log())
    result = GF(0)
    for coeff in coeffs_e:
        sm = coeff + result
        result = sm * root
        print(xz(coeff), xz(sm), xz(result))
    syndromes.append(result)
    print()

print("Синдромы S_j для j = 6, 7, 8, 9, 10, 11:")
for j, s in zip([6, 7, 8, 9, 10, 11], syndromes):
    if s == 0:
        print(f"S_{j} = 0")
    else:
        print(f"S_{j} = α^{s.log()}")
