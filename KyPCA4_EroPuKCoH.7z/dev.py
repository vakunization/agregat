import galois

# Определяем поле GF(2^4) с примитивным полиномом x^4 + x + 1
GF = galois.GF(2**4, irreducible_poly="x^4 + x + 1")
α = GF.primitive_element

# Определяем порождающий многочленg g(x) = α^0x⁵ + α^12x⁴ + α^12x³ + α^5x² + α^6x^1 + α^10x^0
g_coeffs = [1, 1, α**9, α**4, α**11, α**4, α**6]  # коэффициенты от старшей степени
g_poly = galois.Poly(g_coeffs, field=GF)

# Определяем информационный полином i(x)
i_coeffs = [α**7, α**-1, α**4, α**11, α**13, α**2, α**4, α**3, α**5]
# Дополняем нулями до длины 15 (код (15,9))
full_coeffs = i_coeffs + [0] * 6
i_poly = galois.Poly(full_coeffs, field=GF)

# Выполняем деление i(x) / g(x)
q, r = divmod(i_poly, g_poly)

print("Информационный полином i(x):")
print(f"i(x) = {i_poly}")

print("\nПорождающий полином g(x):")
print(f"g(x) = {g_poly}")

print("\nОстаток r(x):")
print(f"r(x) = {r}")

# Вывод коэффициентов остатка в виде степеней α
print("\nКоэффициенты остатка r(x) в виде степеней α:")
if r.degree >= 0:
    for i, coeff in enumerate(r.coeffs):
        if coeff != 0:
            exp = coeff.log()
            power = r.degree - i
            print(f"Коэффициент при x^{power}: α^{exp}")
        else:
            power = r.degree - i
            print(f"Коэффициент при x^{power}: 0")
else:
    print("Остаток равен 0")
